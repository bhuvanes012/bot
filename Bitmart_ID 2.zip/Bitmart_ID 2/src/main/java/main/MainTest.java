package main;

import com.bitmart.api.Call;
import com.bitmart.api.CloudContext;
import com.bitmart.api.key.CloudKey;
import com.google.gson.Gson;

import pojo.bookOrder.Buy;
import pojo.bookOrder.OrderBookResponce;
import pojo.bookOrder.Sell;
import pojo.latestPrice.SymbolDetails;
import service.SeriverApi;
import util.TradeUtil;

public class MainTest {
	public static String CLOUD_URL = "https://api-cloud.bitmart.com";
	public static String API_KEY = "a640b120485f61f111431bde9af10523745da077";
	public static String API_SECRET = "0f07ceac16aa7e83399fe0ef5aac64447bc6b78d607dd0c11610c8eb4446b113";
	public static String API_MEMO = "algo";
	static CloudContext cloudContext = new CloudContext(CLOUD_URL, new CloudKey(API_KEY, API_SECRET, API_MEMO));
	public static Call call = new Call(cloudContext);;

	public static long buyLastOrderID = 0;
	public static double buyLastOrderPrice = 0;

	public static long sellLastOrderID = 0;
	public static double sellLastOrderPrice = 0;
	
	//this Amount used to decide the buy and sell greater than this amount
    public static double maxOrderConfirmLimit =50000;

	Gson gson = new Gson();

	public static void main(String[] args) {

		System.out.println("Trade Started ...................");
		while (true) {
			// 200853531427073733

			String symbol = "WELT_USDT";
			//TradeUtil.increasePrice("0.008500");
			SeriverApi service = new SeriverApi();
			// boolean balancea =
			// service.getOpenOrderDetails(Long.parseLong("200853531427073733"));
			 //Double balance = service.getAccountCoinBalance("USDT");
			// Long orderId= service.sellLimitOrder(symbol, .0085, balance);
			// System.out.println(orderId);
			try {
				 Double balance1 = service.getAccountCoinBalance("USDT");
				 System.out.println("balance   :  "+balance1);
				 
				Thread.sleep(230);
				OrderBookResponce orderBookResponce = new OrderBookResponce();
				TradeUtil tradeUtil = new TradeUtil();

				orderBookResponce = service.getOrderBookData(symbol, 15);
				SymbolDetails symbolDetail = service.getLatestPrice(symbol);
				Double latestPrice = symbolDetail.last;
				System.out.println("price ---> "+latestPrice);
//				double decreasedPrice = 0;
//				double increasedPrice = 0;
//				if (orderBookResponce != null && latestPrice != 0 && latestPrice != null) {
//
//					decreasedPrice = tradeUtil.decreasePrice(latestPrice, 5);
//					increasedPrice = tradeUtil.increasePrice(latestPrice, 5);
//					//buy logic implemented inside this method
//					buyLogic(orderBookResponce, latestPrice, decreasedPrice, symbol);
//					//sell logic implemented inside this method
//					sellLogic(orderBookResponce, latestPrice, increasedPrice, symbol);
//					 
//
//					 
//				}
//				tradeUtil.print(orderBookResponce.data.buys.get(0).amount);
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				//This method used to Delete the unwanted object in JVM
				System.gc();
			}
		}

	}

	private static void sellLogic(OrderBookResponce orderBookResponce, Double latestPrice, double increasedPrice,
			String symbol) {
		TradeUtil tradeUtil = new TradeUtil();
		SeriverApi service = new SeriverApi();
		try {
			boolean overAllSellStatus = false;
			boolean status =false;
			for (Sell data : orderBookResponce.data.sells) {
				tradeUtil.print(data.price);
				// if book order price is less than or equal to decreased price it's break the
				// loop
				if (increasedPrice <= tradeUtil.converToDouble(data.price)) {
					break;
				}
				double buyQuantity = tradeUtil.converToDouble(data.amount);
				// Check the mention in book order value greater than or not
				if (buyQuantity > maxOrderConfirmLimit) {
					
					overAllSellStatus = true;
					tradeUtil.print(data.price);
					// once buy condition satisfy then check the sell order data

					status = validateBuyOrderBook(data.amount, latestPrice, symbol);
					if (status && sellLastOrderPrice == 0) {
						
						double placeOrderPrice = TradeUtil.decreasePrice(data.price);
						Double balance = service.getAccountCoinBalance("WELT");
						if (balance != null) {
							Double totalUSDT = balance * placeOrderPrice;
							if (totalUSDT > 5 && placeOrderPrice >=tradeUtil.decreasePrice(latestPrice, 1) ) {
								Long orderID = service.sellLimitOrder(symbol, placeOrderPrice, balance);
								if (orderID != null && orderID != 0) {
									sellLastOrderID = orderID;
									sellLastOrderPrice =  tradeUtil.converToDouble(data.price);
									break;
								}
							} else {
								sellLastOrderID = 0;
								sellLastOrderPrice = 0;
							}
						}
					} else if (status && sellLastOrderPrice != 0) {
						boolean fillStatus = service.getOpenOrderDetails(sellLastOrderID);
						if (sellLastOrderPrice != tradeUtil.converToDouble(data.price) && fillStatus) {
							Boolean cancelStatus = service.cancelOrder(String.valueOf(sellLastOrderID), symbol);
							if (cancelStatus) {
								sellLastOrderID = 0;
								sellLastOrderPrice = 0;
								double placeOrderPrice = TradeUtil.decreasePrice(data.price);
								Double balance = service.getAccountCoinBalance("WELT");
								if (balance != null) {
									Double totalUSDT = balance * placeOrderPrice;
									if (totalUSDT > 5 && placeOrderPrice >= tradeUtil.decreasePrice(latestPrice, 1)) {
										Long orderID = service.sellLimitOrder(symbol, placeOrderPrice, balance);
										if (orderID != null && orderID != 0) {
											sellLastOrderID = orderID;
											sellLastOrderPrice = tradeUtil.converToDouble(data.price);
											break;
										}
									} else {
										sellLastOrderID = 0;
										sellLastOrderPrice = 0;
									}
								}
							}
							
					    // if Order volume is filled then quit the order
						}else if(!fillStatus) {
							sellLastOrderID = 0;
							sellLastOrderPrice = 0;
						}

					}  
				}
			}
			if (status == false && sellLastOrderID != 0) {
				Boolean cancelStatus = service.cancelOrder(String.valueOf(sellLastOrderID), symbol);
				if (cancelStatus) {
					sellLastOrderID = 0;
					sellLastOrderPrice = 0;
				}
			}
			if (!overAllSellStatus && sellLastOrderID != 0) {
				Boolean cancelStatus = service.cancelOrder(String.valueOf(sellLastOrderID), symbol);
				if (cancelStatus) {
					sellLastOrderID = 0;
					sellLastOrderPrice = 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void buyLogic(OrderBookResponce orderBookResponce, Double latestPrice, double decreasedPrice,
			String symbol) {
		TradeUtil tradeUtil = new TradeUtil();
		SeriverApi service = new SeriverApi();
		try {
			boolean overAllBuyStatus = false;
			boolean status =false;
			for (Buy data : orderBookResponce.data.buys) {
				tradeUtil.print(data.price);
				// if book order price is less than or equal to decreased price it's break the
				// loop
				if (decreasedPrice >= tradeUtil.converToDouble(data.price)) {
					break;
				}
				double buyQuantity = tradeUtil.converToDouble(data.amount);
				// Check the mention in book order value greater than or not
				if (buyQuantity > maxOrderConfirmLimit) {
					overAllBuyStatus = true;
					tradeUtil.print(data.price);
					// once buy condition satisfy then check the sell order data

				    status = validateSellOrderBook(data.amount, latestPrice, symbol);
					if (status && buyLastOrderPrice == 0 && buyLastOrderID == 0) {
						double placeOrderPrice = TradeUtil.increasePrice(data.price);
						Double balance = service.getAccountCoinBalance("USDT");
						Double quantity = (balance / placeOrderPrice);
						quantity = tradeUtil.decreasePrice(quantity, 1);
						if (balance > 5 && balance != null && placeOrderPrice <=tradeUtil.increasePrice(latestPrice, 1) ) {
							Long orderID = service.buyLimitOrder(symbol, placeOrderPrice, quantity);
							if (orderID != null && orderID != 0) {
								buyLastOrderID = orderID;
								buyLastOrderPrice = tradeUtil.converToDouble(data.price);
								break;
							}
						} else if (balance != null && balance <= 5) {
							buyLastOrderID = 0;
							buyLastOrderPrice = 0;
						}

					} else if (status && buyLastOrderPrice != 0 && buyLastOrderID != 0) {
						boolean fillStatus = service.getOpenOrderDetails(buyLastOrderID);
						if (buyLastOrderPrice != tradeUtil.converToDouble(data.price) && fillStatus) {
							Boolean cancelStatus = service.cancelOrder(String.valueOf(buyLastOrderID), symbol);
							if (cancelStatus) {
								buyLastOrderID = 0;
								buyLastOrderPrice = 0;
								double placeOrderPrice = TradeUtil.increasePrice(data.price);
								Double balance = service.getAccountCoinBalance("USDT");
								Double quantity = (balance / placeOrderPrice);
								quantity = tradeUtil.decreasePrice(quantity, 1);
								if (balance > 5 && balance != null && placeOrderPrice <= tradeUtil.increasePrice(latestPrice, 1)) {
									Long orderID = service.buyLimitOrder(symbol, placeOrderPrice, quantity);
									if (orderID != null && orderID != 0) {
										buyLastOrderID = orderID;
										buyLastOrderPrice = tradeUtil.converToDouble(data.price);
										break;
									}
								} else if (balance != null && balance <= 5) {
									buyLastOrderID = 0;
									buyLastOrderPrice = 0;
								}

							}
						//if Order is filled then quit the order
						}else if(!fillStatus) {
							buyLastOrderID = 0;
							buyLastOrderPrice = 0;
						}

					}  
				}
			}
			if (status == false && buyLastOrderID != 0) {
				Boolean cancelStatus = service.cancelOrder(String.valueOf(buyLastOrderID), symbol);
				if (cancelStatus) {
					buyLastOrderID = 0;
					buyLastOrderPrice = 0;
				}

			}
			if (!overAllBuyStatus && buyLastOrderID != 0) {
				Boolean cancelStatus = service.cancelOrder(String.valueOf(buyLastOrderID), symbol);
				if (cancelStatus) {
					buyLastOrderID = 0;
					buyLastOrderPrice = 0;
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static boolean validateBuyOrderBook(String price, double latestPrice, String symbol) {
		try {
			TradeUtil tradeUtil = new TradeUtil();
			OrderBookResponce orderBookResponce = new OrderBookResponce();
			SeriverApi service = new SeriverApi();

			orderBookResponce = service.getOrderBookData(symbol, 15);
			double totalSellOrder = 0;
			for (Buy buy : orderBookResponce.data.buys) {
				double increasedPrice = tradeUtil.decreasePrice(latestPrice, 10);
				if (increasedPrice >= tradeUtil.converToDouble(buy.price)) {
					break;
				}
				totalSellOrder += tradeUtil.converToDouble(buy.amount);
			}
			double tragetPrice = tradeUtil.converToDouble(price) / 2;
			tradeUtil.print("total Sell: " + totalSellOrder);
			if (tragetPrice < totalSellOrder) {
				// false
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	/*
	 * This method used to validate sell order book Highest order value in buy order
	 * is divided by 2 And the same time check the sell order book sum of all order
	 */
	private static boolean validateSellOrderBook(String price, double latestPrice, String symbol) {
		try {
			TradeUtil tradeUtil = new TradeUtil();
			OrderBookResponce orderBookResponce = new OrderBookResponce();
			SeriverApi service = new SeriverApi();

			orderBookResponce = service.getOrderBookData(symbol, 15);
			double totalSellOrder = 0;
			for (Sell sell : orderBookResponce.data.sells) {
				double increasedPrice = tradeUtil.increasePrice(latestPrice, 7);
				if (increasedPrice <= tradeUtil.converToDouble(sell.price)) {
					break;
				}
				totalSellOrder += tradeUtil.converToDouble(sell.amount);
			}
			double tragetPrice = tradeUtil.converToDouble(price) / 2;
			tradeUtil.print("total Sell: " + totalSellOrder);
			if (tragetPrice < totalSellOrder) {
				// false
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

}
