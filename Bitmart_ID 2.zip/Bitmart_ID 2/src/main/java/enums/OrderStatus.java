package enums;

public enum OrderStatus {
		BUY,SELL
}
