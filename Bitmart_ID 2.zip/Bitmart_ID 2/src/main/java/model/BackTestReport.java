package model;

public class BackTestReport {
    private double currentBalance;
    private double quantity;
    private String comment;
    private double profit;
    private String price;

     

    
    
    public String getPrice() {
		return price;
	}



	public void setPrice(String price) {
		this.price = price;
	}



	// Getters and Setters
    public double getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }



    @Override
    public String toString() {
        return String.format(
            "{\"currentBalance\": %.2f, \"quantity\": %.4f, \"comment\": \"%s\", \"profit\": %.2f, \"price\": %s}", 
            currentBalance, quantity, comment, profit, price
        );
    }

    
    
}
