package model;

import enums.OrderStatus;

public class OrderDetails {
	String price ="0";
	String OrderId ="";
	double quantity = 0;
	boolean isFilled = false;
	OrderStatus orderStatus ;
	double averagePrice = 0;
	double averageFilledQunatity = 0;
	double orderPlacedPrice = 0;
	
	
	
	
	public double getOrderPlacedPrice() {
		return orderPlacedPrice;
	}
	public void setOrderPlacedPrice(double orderPlacedPrice) {
		this.orderPlacedPrice = orderPlacedPrice;
	}
	public double getAverageFilledQunatity() {
		return averageFilledQunatity;
	}
	public void setAverageFilledQunatity(double averageFilledQunatity) {
		this.averageFilledQunatity = averageFilledQunatity;
	}
	public double getAveragePrice() {
		return averagePrice;
	}
	public void setAveragePrice(double averagePrice) {
		this.averagePrice = averagePrice;
	}
	public void setFilled(boolean isFilled) {
		this.isFilled = isFilled;
	}
	public OrderStatus getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getOrderId() {
		return OrderId;
	}
	public void setOrderId(String orderId) {
		OrderId = orderId;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public boolean isFilled() {
		return isFilled;
	}
	public void setIsFilled(boolean isFilled) {
		this.isFilled = isFilled;
	}
	@Override
	public String toString() {
		return "OrderDetails [price=" + price + ", OrderId=" + OrderId + ", quantity=" + quantity + ", isFilled="
				+ isFilled + ", orderStatus=" + orderStatus + "]";
	}
	
	

}
