package model;

public class Symbol {
	    private String symbol;
	    
	    private int pricePrecision;
	    private String minAmount;
	    private String status;
	    private String minQuantity;
	    
	    
		public String getMinQuantity() {
			return minQuantity;
		}
		public void setMinQuantity(String minQuantity) {
			this.minQuantity = minQuantity;
		}
		public String getSymbol() {
			return symbol;
		}
		public void setSymbol(String symbol) {
			this.symbol = symbol;
		}
		 
		public int getPricePrecision() {
			return pricePrecision;
		}
		public void setPricePrecision(int pricePrecision) {
			this.pricePrecision = pricePrecision;
		}
		public String getMinAmount() {
			return minAmount;
		}
		public void setMinAmount(String minAmount) {
			this.minAmount = minAmount;
		}
		 
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		@Override
		public String toString() {
			return "Symbol [symbol=" + symbol + ", pricePrecision=" + pricePrecision + ", minAmount=" + minAmount
					+ ", status=" + status + ", minQuantity=" + minQuantity + "]";
		}
		 
		 
	    
	    
}
