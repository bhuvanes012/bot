package model;

import java.util.ArrayList;
import java.util.List;

public class AlgoDataModel {
	double currentHighPrice = 0;
	double entryPrice = 0;
	double quantity = 0;
	String symbol ="";
	double maxProfit =0;
	
	 
	ArrayList<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
	
	
	
	
	 
	public double getCurrentHighPrice() {
		return currentHighPrice;
	}
	public void setCurrentHighPrice(double currentHighPrice) {
		this.currentHighPrice = currentHighPrice;
	}
	public double getEntryPrice() {
		return entryPrice;
	}
	public void setEntryPrice(double entryPrice) {
		this.entryPrice = entryPrice;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public double getMaxProfit() {
		return maxProfit;
	}
	public void setMaxProfit(double maxProfit) {
		this.maxProfit = maxProfit;
	}
	public ArrayList<OrderDetails> getOrderDetails() {
		return this.orderDetails;
	}
	public void setOrderDetails(ArrayList<OrderDetails> allOrder) {
		 this.orderDetails = allOrder;
		
	}
	
	

}
