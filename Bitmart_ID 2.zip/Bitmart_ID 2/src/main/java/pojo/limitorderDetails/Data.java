
package pojo.limitorderDetails;
  
  
public class Data {
 
	    private String orderId;
	    private String clientOrderId;
	    private String symbol;
	    private String side;
	    private String orderMode;
	    private String type;
	    private String state;
	    private String price;
	    private String priceAvg;
	    private String size;
	    private String filledSize;
	    private String notional;
	    private String filledNotional;
	    private Long createTime;
	    private Long updateTime;

	    public String getOrderId() {
	        return orderId;
	    }

	    public void setOrderId(String orderId) {
	        this.orderId = orderId;
	    }

	    public String getClientOrderId() {
	        return clientOrderId;
	    }

	    public void setClientOrderId(String clientOrderId) {
	        this.clientOrderId = clientOrderId;
	    }

	    public String getSymbol() {
	        return symbol;
	    }

	    public void setSymbol(String symbol) {
	        this.symbol = symbol;
	    }

	    public String getSide() {
	        return side;
	    }

	    public void setSide(String side) {
	        this.side = side;
	    }

	    public String getOrderMode() {
	        return orderMode;
	    }

	    public void setOrderMode(String orderMode) {
	        this.orderMode = orderMode;
	    }

	    public String getType() {
	        return type;
	    }

	    public void setType(String type) {
	        this.type = type;
	    }

	    public String getState() {
	        return state;
	    }

	    public void setState(String state) {
	        this.state = state;
	    }

	    public String getPrice() {
	        return price;
	    }

	    public void setPrice(String price) {
	        this.price = price;
	    }

	    public String getPriceAvg() {
	        return priceAvg;
	    }

	    public void setPriceAvg(String priceAvg) {
	        this.priceAvg = priceAvg;
	    }

	    public String getSize() {
	        return size;
	    }

	    public void setSize(String size) {
	        this.size = size;
	    }

	    public String getFilledSize() {
	        return filledSize;
	    }

	    public void setFilledSize(String filledSize) {
	        this.filledSize = filledSize;
	    }

	    public String getNotional() {
	        return notional;
	    }

	    public void setNotional(String notional) {
	        this.notional = notional;
	    }

	    public String getFilledNotional() {
	        return filledNotional;
	    }

	    public void setFilledNotional(String filledNotional) {
	        this.filledNotional = filledNotional;
	    }

	    public Long getCreateTime() {
	        return createTime;
	    }

	    public void setCreateTime(Long createTime) {
	        this.createTime = createTime;
	    }

	    public Long getUpdateTime() {
	        return updateTime;
	    }

	    public void setUpdateTime(Long updateTime) {
	        this.updateTime = updateTime;
	    }
	


}
