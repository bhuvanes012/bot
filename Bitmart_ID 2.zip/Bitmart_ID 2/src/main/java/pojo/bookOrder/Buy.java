package pojo.bookOrder;

public class Buy {
	 public String amount;
	 public String total;
	 public String price;
	 public String count;
}
