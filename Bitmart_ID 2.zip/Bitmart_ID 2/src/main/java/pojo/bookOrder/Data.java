package pojo.bookOrder;

import java.util.ArrayList;

public class Data {
	 public long timestamp;
	 public ArrayList<Buy> buys;
	 public ArrayList<Sell> sells;
}
