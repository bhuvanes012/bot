package pojo.bookOrder;

public class Sell {
	public String amount;
	 public String total;
	 public String price;
	 public String count;
}
