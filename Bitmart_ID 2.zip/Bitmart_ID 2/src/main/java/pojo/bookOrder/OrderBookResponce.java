package pojo.bookOrder;

import java.util.ArrayList;
 
 public class OrderBookResponce  {
 public String message;
 public int code;
 public String trace;
 public Data data;
}
 
