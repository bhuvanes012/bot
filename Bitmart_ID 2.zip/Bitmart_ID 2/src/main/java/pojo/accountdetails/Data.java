
package pojo.accountdetails;

import java.util.List;  
 

public class Data {
 
    public List<Wallet> wallet;

     
    public List<Wallet> getWallet() {
		return wallet;
	}


	public void setWallet(List<Wallet> wallet) {
		this.wallet = wallet;
	}


	public static class Wallet {
    	private String available;
        private String currency;
        private String frozen;
        private String name;
        public String getAvailable() {
			return available;
		}
		public void setAvailable(String available) {
			this.available = available;
		}
		public String getCurrency() {
			return currency;
		}
		public void setCurrency(String currency) {
			this.currency = currency;
		}
		public String getFrozen() {
			return frozen;
		}
		public void setFrozen(String frozen) {
			this.frozen = frozen;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		

       

    }
}
