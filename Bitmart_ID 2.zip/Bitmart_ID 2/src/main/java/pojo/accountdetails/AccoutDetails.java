
package pojo.accountdetails;
  
 
public class AccoutDetails {

    public Long code;
    public Data data;
    public String message;
    public Long getCode() {
		return code;
	}
	public void setCode(Long code) {
		this.code = code;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getTrace() {
		return trace;
	}
	public void setTrace(String trace) {
		this.trace = trace;
	}
	public String trace;
 
 
}
