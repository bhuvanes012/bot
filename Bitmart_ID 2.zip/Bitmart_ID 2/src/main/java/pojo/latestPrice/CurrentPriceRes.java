package pojo.latestPrice;
 

public class CurrentPriceRes {
	public String message;
	 public int code;
	 public String trace;
	 public SymbolDetails data;
}
