package pojo.latestPrice;

public class SymbolDetails {
	    public String symbol;
	    public Double last;
	    public String v_24h;
	    public String qv_24h;
	    public String open_24h;
	    public String high_24h;
	    public String low_24h;
	    public String fluctuation;
	    public String bid_px;
	    public String bid_sz;
	    public String ask_px;
	    public String ask_sz;
	    public String ts;
}
