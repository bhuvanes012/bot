
package pojo.limitOrderResponse;
  
  
public class Data {
 
    private Long order_id;

    public Long getOrderId() {
        return order_id;
    }

    public void setOrderId(Long orderId) {
    	order_id = orderId;
    }

}
