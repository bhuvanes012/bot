package interfaces;

import java.util.List;

import model.KlineData;
import model.Symbol;
import pojo.latestPrice.SymbolDetails;
import pojo.limitorderDetails.GetLimitOrderStatus;

public interface BitmartService {
	
	public void intilizeConnection();
	public List<Symbol>  getExchangeSymbolInfo();
	public boolean cancelOrder(String symbol,String orderId);
	public String buyLimitOrder(String symbol,double quantity ,double limitPrice);
	public String sellLimitOrder(String symbol,double quantity ,double limitPrice);
	public GetLimitOrderStatus getOpenOrderDetails( String  symbol, String orderId);
	public double getAccountCoinBalance(String symbol);
	public  List<KlineData> fetchHistoricalData( String symbol, String startDate, String endDate);
	public  SymbolDetails  getLatestPrice(String symbol) ;
}
