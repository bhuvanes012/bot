package service;
 
import com.bitmart.api.common.CloudException;
import com.bitmart.api.common.CloudResponse;
import com.bitmart.api.request.account.prv.AccountWalletRequest;
import com.bitmart.api.request.contract.prv.GetOrderDetailRequest;
import com.bitmart.api.request.spot.prv.CancelOrderRequest;
import com.bitmart.api.request.spot.prv.SubmitOrderRequest;
import com.bitmart.api.request.spot.pub.market.V3DepthRequest;
import com.bitmart.api.request.spot.pub.market.V3TickerRequest; 
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import main.MainTest;
import pojo.accountdetails.AccoutDetails;
import pojo.accountdetails.Data;
import pojo.bookOrder.OrderBookResponce;
import pojo.latestPrice.CurrentPriceRes;
import pojo.latestPrice.SymbolDetails;
import pojo.limitOrderResponse.LimitOrderResp;
import pojo.limitorderDetails.GetLimitOrderStatus;
import util.TradeUtil;

public class SeriverApi {

	TradeUtil tradeUtil = new TradeUtil();
	/*
	 * Get the order book value for the symbol
	 */
	public  OrderBookResponce  getOrderBookData(String symbol,int count) {
		OrderBookResponce orderBookData =null;
		try {
		 CloudResponse res =new CloudResponse();
		 Gson gson = new Gson();
		 
	     // Get Ticker of a Trading Pair
		 res =  MainTest.call.callCloud(new V3DepthRequest().setSymbol(symbol).setLimit(count));
	     orderBookData  = gson.fromJson(res.getResponseContent(), OrderBookResponce.class);
	     tradeUtil.print(res.getResponseContent());
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return orderBookData;
	}
	
	/*
	 * Get the latest price of the symbol
	 */
	public  SymbolDetails  getLatestPrice(String symbol) {
		CurrentPriceRes latestPrice =null;
		try {
		 CloudResponse res =new  CloudResponse();
		 Gson gson = new Gson();
	     // Get Ticker of a Trading Pair
		 res = MainTest.call.callCloud(new V3TickerRequest().setSymbol(symbol));
		 latestPrice  = gson.fromJson(res.getResponseContent(), CurrentPriceRes.class);
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return latestPrice.data;
	} 
	
	    public long sellLimitOrder(String symbol,double price, double qty) throws CloudException {
	    	
	    	Gson gson = new Gson();
    	    LimitOrderResp lo = new  LimitOrderResp();
	        try {
	        	//System.out.println("sell enter");
		        String res =   MainTest.call.callCloud(new SubmitOrderRequest()
		                        .setSide("sell").setType("limit")
		                        .setSymbol(symbol).setPrice(String.valueOf(price)).setSize(String.valueOf(qty))).getResponseContent();
		        lo = gson.fromJson(String.valueOf(res), LimitOrderResp.class);
	
		        if(lo.getData().getOrderId()==null){
		            return 0;
		        }
	        }catch (Exception e) {
				e.printStackTrace();
			}
	        return lo.getData().getOrderId();
	    }
	    
	    public long buyLimitOrder(String symbol, double price, double qty) throws CloudException {
	    	LimitOrderResp lo = new  LimitOrderResp();
	    	try { 
	    		//System.out.println("buy enter");
	    	Gson gson = new Gson();
	        String res =   MainTest.call.callCloud(new SubmitOrderRequest()
	                .setSide("buy").setType("limit")
	                .setSymbol(symbol).setPrice(String.valueOf(price)).setSize(String.valueOf(qty))).getResponseContent();
	        lo = gson.fromJson(String.valueOf(res), LimitOrderResp.class);
	       // System.out.println(res);
	        if(lo.getData().getOrderId()==null){
	            return 0;
	        }
	    	}catch (Exception e) {
				e.printStackTrace();
			}
	        return lo.getData().getOrderId();
	    }
	    public boolean getOpenOrderDetails( long orderId) throws CloudException {
	    	try {
		    	Gson gson = new Gson();
		        GetLimitOrderStatus getStatus = new GetLimitOrderStatus();
		        String res= MainTest.call.callCloud(new GetOrderDetailRequest().setOrderId(String.valueOf(orderId))).getResponseContent();
		        getStatus = gson.fromJson(String.valueOf(res), GetLimitOrderStatus.class);
		        if(getStatus.getData().getState().equalsIgnoreCase("filled")){
		            return false;
		        }else {
		            return true;
		        }
	    	}catch (Exception e) {
	    		 return true;
			}

	    }
	    
	    
	    public boolean getOpenOrderDetailsOfUnFiled( long orderId) throws CloudException {
	    	try {
		    	Gson gson = new Gson();
		        GetLimitOrderStatus getStatus = new GetLimitOrderStatus();
		        String res= MainTest.call.callCloud(new GetOrderDetailRequest().setOrderId(String.valueOf(orderId))).getResponseContent();
		        getStatus = gson.fromJson(String.valueOf(res), GetLimitOrderStatus.class);
		        if(getStatus.getData().getState().equalsIgnoreCase("filled")){
		            return false;
		        }else {
		            return true;
		        }
	    	}catch (Exception e) {
	    		 return false;
			}

	    }
	    @SuppressWarnings("null")
		public double getAccountCoinBalance(String symbol) throws CloudException {
	    	try {
		    	Gson gson = new Gson();
		        AccoutDetails ad = new AccoutDetails();
	
		        ad = gson.fromJson(String.valueOf(MainTest.call.callCloud(new AccountWalletRequest()).getResponseContent()), AccoutDetails.class);
		        for (Data.Wallet wallet: ad.getData().getWallet()) {
		        	//System.out.println(wallet.getCurrency());
		            if (wallet.getCurrency().equalsIgnoreCase(symbol)){
		                return tradeUtil.converToDouble(wallet.getAvailable());
		            }
		        }
	    	}catch (Exception e) {
			    e.printStackTrace();
			}
	        return (Double) null;
	    }
	    
	    public boolean cancelOrder(String orderId,String symbol) {
	    	
	    	try {
	    		Gson gson = new Gson();
	    		 
	    		CloudResponse responce = new CloudResponse();
	    		responce = MainTest.call.callCloud(new CancelOrderRequest().setSymbol(symbol).setOrder_id(orderId));
	    		JsonObject details = JsonParser.parseString(responce.getResponseContent())
	    			    .getAsJsonObject();
	    		//System.out.println(responce.getResponseContent());
	    		String result = details.get("message").toString();
	    		if(result.contains("OK") || result.contains("Already")) {
	    			return true;
	    		}else {
	    			 return false;
					 
	    		}
			} catch (CloudException e) {
				e.printStackTrace();
				return false;
			}
	    }
	    
}
