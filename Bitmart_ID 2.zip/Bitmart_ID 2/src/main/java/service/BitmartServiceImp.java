package service;
 
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import com.bitmart.api.Call;
import com.bitmart.api.CloudContext;
import com.bitmart.api.common.CloudException;
import com.bitmart.api.common.CloudResponse;
import com.bitmart.api.key.CloudKey;
import com.bitmart.api.request.account.prv.AccountWalletRequest;
import com.bitmart.api.request.contract.prv.GetOrderDetailRequest;
import com.bitmart.api.request.spot.prv.CancelOrderRequest; 
import com.bitmart.api.request.spot.prv.SubmitOrderRequest;
import com.bitmart.api.request.spot.prv.v4.V4QueryOrderByOrderIdRequest;
import com.bitmart.api.request.spot.pub.SymbolsDetailsRequest;
import com.bitmart.api.request.spot.pub.market.V3HistoryKlineRequest;
import com.bitmart.api.request.spot.pub.market.V3TickerRequest;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser; 

import interfaces.BitmartService;
import japa.parser.ParseException;
import main.MainTest;
import model.KlineData;
import model.Symbol;
import pojo.accountdetails.AccoutDetails;
import pojo.accountdetails.Data;
import pojo.latestPrice.CurrentPriceRes;
import pojo.latestPrice.SymbolDetails;
import pojo.limitOrderResponse.LimitOrderResp;
import pojo.limitorderDetails.GetLimitOrderStatus;
import util.TradeUtil;

public class BitmartServiceImp implements BitmartService{
	public static String CLOUD_URL = "https://api-cloud.bitmart.com";
	public static String API_KEY = "a640b120485f61f111431bde9af10523745da077";
	public static String API_SECRET = "0f07ceac16aa7e83399fe0ef5aac64447bc6b78d607dd0c11610c8eb4446b113";
	public static String API_MEMO = "algo";
	static CloudContext cloudContext =null;
	Call call = null;
	Gson gson = new Gson();
	
	TradeUtil tradeUtil = new TradeUtil();
	
	  private static final int TIME_INTERVAL = 60; // 1-minute
	    private static final Integer MAX_LIMIT = 200; // Max records per request
	    private static final int API_RATE_LIMIT = 10; // Max 10 API calls per 2 seconds

	
	public void intilizeConnection() {
	 try {
		
	 cloudContext = new CloudContext(CLOUD_URL, new CloudKey(API_KEY, API_SECRET, API_MEMO));
	 call = new Call(cloudContext);
	 
//	 newOrder data1 =   new newOrder();
//	 data1.symbol = "WELT_USDT";
//	 data1.side ="sell";
//	 data1.type = "limit";
//	 data1.tradeAmount = "10000"; 
//	 data1.tradePrice ="0.0009";
//	 data1.triggerPrice ="0.0009";
//	 data1.orderModeCode ="normal_order";
//	 data1.subOrderModeCode ="normal_order";
//	 data1.marketAmountType ="1";  
//	 data1.timeInForce ="IOC"; 
//	 data1.sign = "c29a38a9146915e8769ab1485dc04441";
//	data1.tradeSide ="2";
//	 
//	 CloudResponse response3 = call.callCloud(new newOrder2());
//	 JsonObject obj = JsonParser.parseString(response3.getResponseContent()).getAsJsonObject();
//	 JsonObject data3 = obj.get("data").getAsJsonObject();
//	 String time  = data3.get("server_time").getAsString();
//	 
//	data1.reqNos= "ES"+System.currentTimeMillis()+"qfqaw2D6ss";
//	 data1.timestamp = Long.parseLong(time) ;
//             // Order quantity
//	 cloudContext = new CloudContext("https://www.bitmart.com", new CloudKey(API_KEY, API_SECRET, API_MEMO));
//	 call = new Call(cloudContext);
//	 
//	 CloudResponse response2 = call.callCloud(data1);
	 
	 
	 }catch (Exception e) {
		e.printStackTrace();
		System.exit(1);
	}
	}
	@Override
	public boolean cancelOrder(String symbol,String orderId ) {
		try {
    		 
    		CloudResponse responce = new CloudResponse();
    		responce = MainTest.call.callCloud(new CancelOrderRequest().setSymbol(symbol).setOrder_id(orderId));
    		JsonObject details = JsonParser.parseString(responce.getResponseContent())
    			    .getAsJsonObject();
    		//System.out.println(responce.getResponseContent());
    		String result = details.get("message").toString();
    		if(result.contains("OK") || result.contains("Already")) {
    			return true;
    		}else {
    			 return false;
				 
    		}
		} catch (CloudException e) {
			e.printStackTrace();
			return false;
		}
	}
	@Override
	public String buyLimitOrder(String symbol, double quantity, double limitPrice) {
		LimitOrderResp lo = new  LimitOrderResp();
    	try { 
    		//System.out.println("buy enter");
    	Gson gson = new Gson();
        String res =   MainTest.call.callCloud(new SubmitOrderRequest()
                .setSide("buy").setType("limit")
                .setSymbol(symbol).setPrice(String.valueOf(limitPrice)).setSize(String.valueOf(quantity))).getResponseContent();
        lo = gson.fromJson(String.valueOf(res), LimitOrderResp.class);
       // System.out.println(res);
        if(lo.getData().getOrderId()==null){
            return "";
        }
    	}catch (Exception e) {
			e.printStackTrace();
		}
        return lo.getData().getOrderId().toString();
 
	}
	@Override
	public String sellLimitOrder(String symbol, double quantity, double limitPrice) {
		 
	    LimitOrderResp lo = new  LimitOrderResp();
        try {
        	if ((quantity * limitPrice) < 5) {
        		return "";
        	}
        	
        	//System.out.println("sell enter");
	        String res =   MainTest.call.callCloud(new SubmitOrderRequest()
	                        .setSide("sell").setType("limit")
	                        .setSymbol(symbol).setPrice(String.valueOf(limitPrice)).setSize(String.valueOf(quantity))).getResponseContent();
	        lo = gson.fromJson(String.valueOf(res), LimitOrderResp.class);

	        if(lo.getData().getOrderId()==null){
	            return "";
	        }
        }catch (Exception e) {
			e.printStackTrace();
		}
        return lo.getData().getOrderId().toString();
	}
	@Override
	public GetLimitOrderStatus getOpenOrderDetails(String symbol ,String orderId) {
		GetLimitOrderStatus getStatus = new GetLimitOrderStatus();
		try {
	    	Gson gson = new Gson();
	       
	        String res= MainTest.call.callCloud(new V4QueryOrderByOrderIdRequest().setOrderId(orderId)).getResponseContent();
	        getStatus = gson.fromJson(String.valueOf(res), GetLimitOrderStatus.class);
	        
	        //new,partially_filled,filled,canceled,partially_canceled,failed
	        return getStatus;
    	}catch (Exception e) {
    		e.printStackTrace();
    		 
		}
		return getStatus;
	}
	@Override
	public double getAccountCoinBalance(String symbol) {
		try {
	    	Gson gson = new Gson();
	        AccoutDetails ad = new AccoutDetails();
	        if(symbol.contains("_")) {
	        	String[] sy = symbol.split("_");
	        	symbol=sy[0];
	        }

	        ad = gson.fromJson(String.valueOf(call.callCloud(new AccountWalletRequest()).getResponseContent()), AccoutDetails.class);
	        for (Data.Wallet wallet: ad.getData().getWallet()) {
	        	//System.out.println(wallet.getCurrency());
	            if (wallet.getCurrency().equalsIgnoreCase(symbol)){
	                return tradeUtil.converToDouble(wallet.getAvailable());
	            }
	        }
    	}catch (Exception e) {
		    e.printStackTrace();
		}
        return (Double) null;
	}
	public  List<KlineData> fetchHistoricalData( String symbol, String startDate, String endDate) {
      
		List<KlineData> historicalData = new ArrayList<>();
		 try {
        long startTime = convertToUnixTimestamp(startDate);
        long endTime = convertToUnixTimestamp(endDate);

        while (startTime < endTime) {
            long requestEndTime = Math.min(startTime + (MAX_LIMIT * TIME_INTERVAL), endTime);
            
            CloudResponse response =call.callCloud(new  V3HistoryKlineRequest().setSymbol(symbol).setLimit(MAX_LIMIT).setBefore(requestEndTime).setAfter(startTime));
            JsonObject details = JsonParser.parseString(response.getResponseContent()).getAsJsonObject();
                JsonArray klineArray = details.get("data").getAsJsonArray();
                for (JsonElement element : klineArray) {
                    JsonArray kline = element.getAsJsonArray();
                    historicalData.add(new KlineData(
                            tradeUtil.convertLongToDate(kline.get(0).getAsLong()) , kline.get(1).getAsString(), kline.get(2).getAsString(),
                            kline.get(3).getAsString(), kline.get(4).getAsString(), kline.get(5).getAsString()
                    ));
                }
            
            startTime = requestEndTime;
            TimeUnit.MILLISECONDS.sleep(200); // API Rate Limit: 10 calls per 2 seconds
        }
		 }catch (Exception e) {
			// TODO: handle exception
		}
        return historicalData;
    }
	 public static long convertToUnixTimestamp(String dateStr) throws Exception {
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        sdf.setTimeZone(TimeZone.getTimeZone("UTC")); 
	        return sdf.parse(dateStr).getTime() / 1000;
	    }
	 
	 
	 /*
		 * Get the latest price of the symbol
		 */
		public  SymbolDetails  getLatestPrice(String symbol) {
			CurrentPriceRes latestPrice =null;
			try {
			 CloudResponse res =new  CloudResponse();
			 Gson gson = new Gson();
		     // Get Ticker of a Trading Pair
			 res = MainTest.call.callCloud(new V3TickerRequest().setSymbol(symbol));
			 latestPrice  = gson.fromJson(res.getResponseContent(), CurrentPriceRes.class);
			}
			catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			return latestPrice.data;
		}
		@Override
		public List<Symbol> getExchangeSymbolInfo() {
			List<Symbol> exchangeSymbolInfo = new ArrayList<Symbol>();
			try {
				 CloudResponse response = call.callCloud(new SymbolsDetailsRequest());
				 JsonObject details = JsonParser.parseString(response.getResponseContent())
						    .getAsJsonObject();
				 String msg = details.get("message").toString();
				 if(!msg.trim().equalsIgnoreCase("ok")) {
					 new RuntimeException("Unable to get Exchange info");
				 }
				 JsonObject data = details.get("data").getAsJsonObject();
				 JsonArray symbols = data.get("symbols").getAsJsonArray();
				 for(JsonElement list : symbols) {
					 JsonObject symbolDetalis = list.getAsJsonObject();
					 Symbol symbol = new Symbol();
					 symbol.setSymbol(symbolDetalis.get("symbol").getAsString().toString()); 
			         symbol.setMinQuantity(symbolDetalis.get("base_min_size").getAsString());
			         symbol.setPricePrecision(symbolDetalis.get("price_max_precision").getAsInt());
			         symbol.setMinAmount(symbolDetalis.get("min_buy_amount").getAsString());
			         symbol.setStatus(symbolDetalis.get("trade_status").getAsString());
			         exchangeSymbolInfo.add(symbol);
			         if(symbol.getSymbol().toLowerCase().contains("welt")) {
			     	     System.out.println(symbolDetalis);
			         }
				 }
			}catch (Exception e) {
				 System.err.println("Failed to fetch exchange info: ");
			}
			return exchangeSymbolInfo;
		} 
	 
}
