package service;

import com.bitmart.api.annotations.ParamKey;
import com.bitmart.api.request.Auth;
import com.bitmart.api.request.CloudRequest;
import com.bitmart.api.request.Method;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;

@EqualsAndHashCode(callSuper = true)
@Data
@ToString
@Accessors(chain = true)
public class newOrder extends CloudRequest {
	 /**
     * Trading pair (e.g. BTC_USDT)
     */
    @ParamKey(value = "symbol", required = true)
    public String symbol;

    /**
     * buy or sell
     */
    @ParamKey(value = "timePeriod", required = true)
    public String side;

    /**
     * Yes	Order type
     * -limit=Limit order
     * -market=Market order
     * -limit_maker=PostOnly order
     * -ioc=IOC order
     */
    @ParamKey(value = "type", required = true)
    public String type;

    /**
     * Client-defined OrderId(A combination of numbers and letters, less than 32 bits)
     */
    @ParamKey("client_order_id")
    public String client_order_id;

    /**
     * Order size || Required for placing orders by quantity
     */
    @ParamKey("size")
    public String size;

    /**
     * Order Price
     */
    @ParamKey("tradePrice")
    public String tradePrice;

    /**
     * Required for placing orders by amount
     */
    @ParamKey("notional")
    public String notional;
    
    
    @ParamKey("triggerPrice")
    public String triggerPrice;
    
    @ParamKey("orderModeCode")
    public String orderModeCode;
    
    @ParamKey("subOrderModeCode")
    public String subOrderModeCode;
    

    @ParamKey("marketAmountType")
    public String marketAmountType;
    
    @ParamKey("tradeAmount")
    public String tradeAmount;
        
    
    
    @ParamKey("reqNo")
    public String reqNos;
    @ParamKey("reqSource")
    public String reqSource;
    
    @ParamKey("timestamp")
    public Long timestamp;
    
    @ParamKey("timeInForce")
    public String timeInForce;
    
    
    @ParamKey("sign")
    public String sign;
    @ParamKey("tradeSide")
    public String tradeSide;
    
	 
    public newOrder() {
    	super("/gw-api/entrust-gateway/client/analyze/trade-data", Method.POST, Auth.SIGNED);
    }
}
