package util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.google.gson.JsonObject; 
import model.Symbol;

public class TradeUtil {

	public  double decreasePrice(double latestPrice, int percentage) {
		 double modifyPrice =  latestPrice- ((latestPrice*percentage)/100);
		return modifyPrice;
	}
	public  double increasePrice(double latestPrice, int percentage) {
		 double modifyPrice =  latestPrice+ ((latestPrice*percentage)/100);
		return modifyPrice;
	}
	@SuppressWarnings("null")
	public  double converToDouble(String price) {
		try {
		double data = Double.parseDouble(price);
		return data;
		}catch (Exception e) {
			
		}
		return (Double) null;
	}
	public void print(String value) {
		//System.out.println(value);
	}
	
	public static double increasePrice(String price) {
		try {
			TradeUtil tradeUtil = new TradeUtil();
		    if(price.contains(".")) {
		    	String[] splitVal = price.split("\\.");
		    	String longdec =   splitVal[1];
		    	String addedValue ="0.";
		    	for(int i=0; i<longdec.length()-1;i++) {
		    		addedValue+="0";
		    	}
		    	Double finalValue =tradeUtil.converToDouble(addedValue+1);
		    	finalValue = tradeUtil.converToDouble(price)+finalValue;
		    	return finalValue;
		    }
			 
		}catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	public static double decreasePrice(String price) {
		try {
			TradeUtil tradeUtil = new TradeUtil();
			 if(price.contains(".")) {
			    	String[] splitVal = price.split("\\.");
			    	String longdec =   splitVal[1];
			    	String addedValue ="0.";
			    	for(int i=0; i<longdec.length()-1;i++) {
			    		addedValue+="0";
			    	}
			    	Double finalValue =tradeUtil.converToDouble(addedValue+1);
			    	finalValue = tradeUtil.converToDouble(price)-finalValue;
			    	return finalValue;
			   }
			 
		}catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
		
	}

	 /**
     * Calculates the percentage drop based on part and total.
     */
    public  double getPercentage(double part, double total) {
        if (total == 0) {
            throw new IllegalArgumentException("Total value cannot be zero");
        }
        return ((part / total) * 100) - 100;
    }
	public void sleep(int milisec) {
		try {
			Thread.sleep(milisec);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public BigDecimal getPricePrecision(String symbol, double price, List<Symbol> exchangeSymbolInfo) {
        // Find the required symbol
        for (Symbol data : exchangeSymbolInfo) {
            if (data.getSymbol().equalsIgnoreCase(symbol)) {
                int precision = data.getPricePrecision();
                return new BigDecimal(price).setScale(precision, RoundingMode.HALF_UP);
            }
        }
        return BigDecimal.ZERO; // Default return if symbol is not found
    }
    
	
	public BigDecimal getQuantityPrecision(String symbol, double price, List<Symbol> exchangeSymbolInfo) {
	    for (Symbol data : exchangeSymbolInfo) {
	        if (data.getSymbol().equalsIgnoreCase(symbol)) {
	            String minQuantity = data.getMinQuantity();
	            
	            if (minQuantity != null && !minQuantity.isEmpty()) {
	                if (minQuantity.equals("1")) {
	                    return new BigDecimal(price).setScale(0, RoundingMode.HALF_UP); // Round to whole number
	                } else if (minQuantity.contains(".")) {
	                    String[] parts = minQuantity.split("\\."); // Fix: Escape dot for regex
	                    return new BigDecimal(price).setScale(parts[1].length(), RoundingMode.HALF_UP);
	                }
	            }
	        }
	    }
	    return BigDecimal.ZERO; // Default return if symbol is not found
	}
	public static double getPrecetageAmount(double price, double precentage) {
		 try {
			 return (price*precentage)/100;
		 }catch (Exception e) {
			return 0;
		} 
	}
	public String convertLongToDate(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // Define format
        Date date = new Date(timestamp); // Convert long to Date
        return sdf.format(date); // Format date to string
    }

    
     
}
