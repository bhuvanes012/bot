package util;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

import model.AlgoDataModel;
 



public class JsonCreationAndUpdate {
	 // Method to load AlgoData from JSON file
    public static AlgoDataModel loadAlgoDataFromFile(String filePath, AlgoDataModel aData) {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File(filePath);
        
        if (file.exists()) {
            try {
                // Read JSON file and convert it to an AlgoData object
                return objectMapper.readValue(file, AlgoDataModel.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
        	System.out.println("File does not exist at: " + filePath);
        	updateJsonFile(aData, filePath);
            return aData;
            
        }
        
        // Return null if file doesn't exist or an error occurred
        return null;
    }
    
    public static void updateJsonFile(AlgoDataModel aData,String fileName) {
		 ObjectMapper objectMapper = new ObjectMapper();
	        try {
	            objectMapper.writeValue(new File(fileName), aData);
	            System.out.println("JSON file created successfully!");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
	}
}
